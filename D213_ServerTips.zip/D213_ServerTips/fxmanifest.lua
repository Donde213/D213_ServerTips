fx_version 'cerulean'
game 'gta5'

lua54 'yes'

shared_scripts {
    -- Only keep this line if you use ox_lib
    '@ox_lib/init.lua',
    'config.lua'
}

client_script 'client.lua'